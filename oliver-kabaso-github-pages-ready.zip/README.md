# Dr. Oliver Kabaso — Academic & Professional Website

Production-ready static website for Dr. Oliver Kabaso.

## Recommended public deployment: GitHub Pages

1. Create/sign in to a GitHub account.
2. Create a **public** repository named exactly:
   `YOUR-GITHUB-USERNAME.github.io`
3. Upload all files in this folder to the repository, including:
   - `index.html`
   - `style.css`
   - `script.js`
   - `.github/workflows/pages.yml`
4. Commit the files to the `main` branch.
5. Open **Settings → Pages** in the repository.
6. Under the build/deployment settings, select **GitHub Actions** if it is not already selected.
7. Open the **Actions** tab and wait for the Pages deployment workflow to finish.
8. Your public website will be available at:
   `https://YOUR-GITHUB-USERNAME.github.io/`

## Optional custom domain: www.oliverkabaso.com

After you own the domain, configure it under:
**Repository → Settings → Pages → Custom domain**

For `www.oliverkabaso.com`, create a DNS CNAME record:
- Host/Name: `www`
- Target: `YOUR-GITHUB-USERNAME.github.io`

For the apex domain `oliverkabaso.com`, GitHub Pages uses its documented A/AAAA records. Configure the domain in GitHub Pages before changing DNS.

Do not put passwords, private documents, identity numbers, or other confidential information in this public repository.

## Website contents

The site includes:
- Professional profile
- Education history
- Academic and research journey
- Research interests
- Selected publications and research works
- Links to public publication/repository records
- Contact information
- Responsive desktop/mobile design
